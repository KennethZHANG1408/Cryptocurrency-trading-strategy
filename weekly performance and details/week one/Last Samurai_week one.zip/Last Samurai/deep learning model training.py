# -*- coding: utf-8 -*-
"""
Created on Sun Sep 28 12:09:23 2018

@author: ZHANG Jian

Special Thanks: Github user "dashee87" for reference
"""


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# read the data of four cryptocurrencies
bt_info = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\data\\BCH-USD_T.csv")
bc_info = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\data\\BTC-USD_T.csv")
et_info = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\data\\ETH-USD_T.csv")
lt_info = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\data\\LTC-USD_T.csv")
# change the name of each column for future merge
bt_info = bt_info.rename(columns={'high':'bt_high', 'low':'bt_low', 'open':'bt_open', 'close': 'bt_close', 'volume':'bt_volume'})
bc_info = bc_info.rename(columns={'high':'bc_high', 'low':'bc_low', 'open':'bc_open', 'close': 'bc_close', 'volume':'bc_volume'})
et_info = et_info.rename(columns={'high':'et_high', 'low':'et_low', 'open':'et_open', 'close': 'et_close', 'volume':'et_volume'})
lt_info = lt_info.rename(columns={'high':'lt_high', 'low':'lt_low', 'open':'lt_open', 'close': 'lt_close', 'volume':'lt_volume'})
split_time = '2018-09-30 00:00:00'
# put the data of four coins into one variable
market_info = pd.merge(bt_info,bc_info, on=['time'])
market_info = pd.merge(market_info,et_info, on=['time'])
market_info = pd.merge(market_info,lt_info, on=['time'])
market_info = market_info[market_info['time']>='2018-08-30 00:00:00']
#d efine two new factors: close price off high price and volatility
for coins in ['bt_', 'bc_', 'et_', 'lt_']: 
    kwargs = { coins+'close_off_high': lambda x: 2*(x[coins+'high']- x[coins+'close'])/(x[coins+'high']-x[coins+'low'])-1, coins+'volatility': lambda x: (x[coins+'high']- x[coins+'low'])/(x[coins+'open'])}
    market_info = market_info.assign(**kwargs)
#transfer all data into one variable  
model_data = market_info[['time']+[coin+metric for coin in ['bt_', 'bc_', 'et_', 'lt_'] 
                                   for metric in ['close','volume','close_off_high','volatility']]]

# in case of some 0/0 = nan cases, we fill the nan with 0 in advance
model_data = model_data.fillna(0)
# need to reverse the data frame so that subsequent rows represent later timepoints
model_data = model_data.sort_values(by='time')
model_data.head()
# define training sets and testing sets
training_set, test_set = model_data[model_data['time']<split_time], model_data[model_data['time']>=split_time]
training_set = training_set.drop('time', 1)
test_set = test_set.drop('time', 1)

window_len = 10
norm_cols = [coin+metric for coin in ['bt_', 'bc_', 'et_', 'lt_'] for metric in ['close','volume']]

#define inputs and pout puts for LSTM training layer
LSTM_training_inputs = []
for i in range(len(training_set)-window_len):
    temp_set = training_set[i:(i+window_len)].copy()
    for col in norm_cols:
        temp_set.loc[:, col] = temp_set[col]/temp_set[col].iloc[0] - 1
    LSTM_training_inputs.append(temp_set)
LSTM_training_outputs = (training_set['et_close'][window_len:].values/training_set['et_close'][:-window_len].values)-1

LSTM_test_inputs = []
for i in range(len(test_set)-window_len):
    temp_set = test_set[i:(i+window_len)].copy()
    for col in norm_cols:
        temp_set.loc[:, col] = temp_set[col]/temp_set[col].iloc[0] - 1
    LSTM_test_inputs.append(temp_set)
LSTM_test_outputs = (test_set['et_close'][window_len:].values/test_set['et_close'][:-window_len].values)-1

# in case of some n/0 = inf , we replace the inf with 0, which can be confirmed not to distort the meaning of data
for i in range(0,len(LSTM_training_inputs)):
    LSTM_training_inputs[i] = LSTM_training_inputs[i].replace(np.inf, 0)
    
for j in range(0,len(LSTM_test_inputs)):
     LSTM_test_inputs[j] = LSTM_test_inputs[j].replace(np.inf, 0)
    
for i in LSTM_training_inputs:
    np.nan_to_num(i, copy = False)
for j in LSTM_test_inputs:
    np.nan_to_num(j, copy = False)
  #%%  
# I found it easier to work with numpy arrays rather than pandas dataframes
# especially as we now only have numerical data
LSTM_training_inputs = [np.array(LSTM_training_input) for LSTM_training_input in LSTM_training_inputs]
LSTM_training_inputs = np.array(LSTM_training_inputs)

LSTM_test_inputs = [np.array(LSTM_test_inputs) for LSTM_test_inputs in LSTM_test_inputs]
LSTM_test_inputs = np.array(LSTM_test_inputs)
# import the relevant Keras modules
from keras.models import Sequential
from keras.layers import Activation, Dense
from keras.layers import LSTM
from keras.layers import Dropout
#%%
# this is a function that is use to build layers in deep learing using Keras and compile the model
def build_model(inputs, output_size, neurons, activ_func="linear",
                dropout=0.25, loss="mae", optimizer="adam"):
    model = Sequential()

    model.add(LSTM(neurons, input_shape=(inputs.shape[1], inputs.shape[2])))
    model.add(Dropout(dropout))
    model.add(Dense(units=output_size))
    model.add(Activation(activ_func))

    model.compile(loss=loss, optimizer=optimizer)
    return model

# random seed for reproducibility
np.random.seed(139)
# initialise model architecture
bch_model = build_model(LSTM_training_inputs, output_size=1, neurons = 30)
# model output is next price normalised to 10th previous closing price
LSTM_training_outputs = (training_set['bc_close'][window_len:].values/training_set['bc_close'][:-window_len].values)-1
# train model on data
# note: eth_history contains information on the training error per epoch
bch_history = bch_model.fit(LSTM_training_inputs, LSTM_training_outputs, epochs=50, batch_size=32, verbose=2, shuffle=True)


# initialise model architecture
btc_model = build_model(LSTM_training_inputs, output_size=1, neurons = 30)
# model output is next price normalised to 10th previous closing price
LSTM_training_outputs = (training_set['bt_close'][window_len:].values/training_set['bt_close'][:-window_len].values)-1
# train model on data
# note: x_history contains information on the training error per epoch
btc_history = btc_model.fit(LSTM_training_inputs, LSTM_training_outputs, epochs=50, batch_size=32, verbose=2, shuffle=True)



# initialise model architecture
eth_model = build_model(LSTM_training_inputs, output_size=1, neurons = 30)
# model output is next price normalised to 10th previous closing price
LSTM_training_outputs = (training_set['et_close'][window_len:].values/training_set['et_close'][:-window_len].values)-1
# train model on data
# note: x_history contains information on the training error per epoch
eth_history = eth_model.fit(LSTM_training_inputs, LSTM_training_outputs, epochs=50, batch_size=32, verbose=2, shuffle=True)


# initialise model architecture
ltc_model = build_model(LSTM_training_inputs, output_size=1, neurons = 30)
# model output is next price normalised to 10th previous closing price
LSTM_training_outputs = (training_set['lt_close'][window_len:].values/training_set['lt_close'][:-window_len].values)-1
# train model on data
# note: x_history contains information on the training error per epoch
ltc_history = ltc_model.fit(LSTM_training_inputs, LSTM_training_outputs, epochs=50, batch_size=32, verbose=2, shuffle=True)


# plot the training error to show the outcome of four models
fig, ax1 = plt.subplots(1,1)

ax1.plot(bch_history.epoch, bch_history.history['loss'])
ax1.set_title('Training Error')

if bch_model.loss == 'mae':
    ax1.set_ylabel('bch model Mean Absolute Error (MAE)',fontsize=12)
# just in case you decided to change the model loss calculation
else:
    ax1.set_ylabel('Model Loss',fontsize=12)
ax1.set_xlabel('# Epochs',fontsize=12)
plt.show()


fig, ax1 = plt.subplots(1,1)

ax1.plot(btc_history.epoch, btc_history.history['loss'])
ax1.set_title('Training Error')

if btc_model.loss == 'mae':
    ax1.set_ylabel('btc model Mean Absolute Error (MAE)',fontsize=12)
# just in case you decided to change the model loss calculation
else:
    ax1.set_ylabel('Model Loss',fontsize=12)
ax1.set_xlabel('# Epochs',fontsize=12)
plt.show()

fig, ax1 = plt.subplots(1,1)

ax1.plot(eth_history.epoch, eth_history.history['loss'])
ax1.set_title('Training Error')

if eth_model.loss == 'mae':
    ax1.set_ylabel('eth model Mean Absolute Error (MAE)',fontsize=12)
# just in case you decided to change the model loss calculation
else:
    ax1.set_ylabel('Model Loss',fontsize=12)
ax1.set_xlabel('# Epochs',fontsize=12)
plt.show()

fig, ax1 = plt.subplots(1,1)

ax1.plot(ltc_history.epoch, ltc_history.history['loss'])
ax1.set_title('Training Error')

if ltc_model.loss == 'mae':
    ax1.set_ylabel('ltc model Mean Absolute Error (MAE)',fontsize=12)
# just in case you decided to change the model loss calculation
else:
    ax1.set_ylabel('Model Loss',fontsize=12)
ax1.set_xlabel('# Epochs',fontsize=12)
plt.show()


#model performance test
"""
from mpl_toolkits.axes_grid1.inset_locator import zoomed_inset_axes
from mpl_toolkits.axes_grid1.inset_locator import mark_inset

fig, ax1 = plt.subplots(1,1)
ax1.set_xticks([datetime.date(i,j,1) for i in range(2013,2019) for j in [1,5,9]])
ax1.set_xticklabels([datetime.date(i,j,1).strftime('%b %Y')  for i in range(2013,2019) for j in [1,5,9]])
ax1.plot(model_data[model_data['time']< split_time]['time'][window_len:].astype(datetime.datetime),
         training_set['et_Close'][window_len:], label='Actual')
ax1.plot(model_data[model_data['time']< split_time]['time'][window_len:].astype(datetime.datetime),
         ((np.transpose(eth_model.predict(LSTM_training_inputs))+1) * training_set['et_Close'].values[:-window_len])[0], 
         label='Predicted')
ax1.set_title('Training Set: Single Timepoint Prediction')
ax1.set_ylabel('Ethereum Price ($)',fontsize=12)
ax1.legend(bbox_to_anchor=(0.15, 1), loc=2, borderaxespad=0., prop={'size': 14})
ax1.annotate('MAE: %.4f'%np.mean(np.abs((np.transpose(eth_model.predict(LSTM_training_inputs))+1)-\
            (training_set['et_Close'].values[window_len:])/(training_set['et_Close'].values[:-window_len]))), 
             xy=(0.75, 0.9),  xycoords='axes fraction',
            xytext=(0.75, 0.9), textcoords='axes fraction')
# figure inset code taken from http://akuederle.com/matplotlib-zoomed-up-inset
axins = zoomed_inset_axes(ax1, 3.35, loc=10) # zoom-factor: 3.35, location: centre
axins.set_xticks([datetime.date(i,j,1) for i in range(2013,2019) for j in [1,5,9]])
axins.plot(model_data[model_data['time']< split_time]['time'][window_len:].astype(datetime.datetime),
         training_set['et_Close'][window_len:], label='Actual')
axins.plot(model_data[model_data['time']< split_time]['time'][window_len:].astype(datetime.datetime),
         ((np.transpose(eth_model.predict(LSTM_training_inputs))+1) * training_set['et_Close'].values[:-window_len])[0], 
         label='Predicted')
axins.set_xlim([datetime.date(2017, 3, 1), datetime.date(2017, 5, 1)])
axins.set_ylim([10,60])
axins.set_xticklabels('')
mark_inset(ax1, axins, loc1=1, loc2=3, fc="none", ec="0.5")
plt.show()

fig, ax1 = plt.subplots(1,1)
ax1.set_xticks([datetime.date(2017,i+1,1) for i in range(12)])
ax1.set_xticklabels([datetime.date(2017,i+1,1).strftime('%b %d %Y')  for i in range(12)])
ax1.plot(model_data[model_data['time']>= split_time]['time'][window_len:].astype(datetime.datetime),
         test_set['et_Close'][window_len:], label='Actual')
ax1.plot(model_data[model_data['time']>= split_time]['time'][window_len:].astype(datetime.datetime),
         ((np.transpose(eth_model.predict(LSTM_test_inputs))+1) * test_set['et_Close'].values[:-window_len])[0], 
         label='Predicted')
ax1.annotate('MAE: %.4f'%np.mean(np.abs((np.transpose(eth_model.predict(LSTM_test_inputs))+1)-\
            (test_set['et_Close'].values[window_len:])/(test_set['et_Close'].values[:-window_len]))), 
             xy=(0.75, 0.9),  xycoords='axes fraction',
            xytext=(0.75, 0.9), textcoords='axes fraction')
ax1.set_title('Test Set: Single Timepoint Prediction',fontsize=13)
ax1.set_ylabel('Ethereum Price ($)',fontsize=12)
ax1.legend(bbox_to_anchor=(0.1, 1), loc=2, borderaxespad=0., prop={'size': 14})
plt.show()
"""