#This week, I want to try a relatively "naive" strategy. I call it "touch and run".
#Assume that the market price is a random Bronian motion, because Brownian motion has not upper or lowwer bound, 
#so any upper limit will be pierced at last. But I want it to pierce in one week. 
#So after I test the data last week, I made a relatively good limit may work.

global cont
global sell
#list of keep and list of sell
cont = [0,1,2,3]
sell = []
def handle_bar(counter,  # a counter for number of minute bars that have already been tested
               time,  # current time in string format such as "2018-07-30 00:30:00"
               data,  # data for current minute bar (in format 2)
               init_cash,  # your initial cash, a constant
               transaction,  # transaction ratio, a constant
               cash_balance,  # your cash balance at current minute
               crypto_balance,  # your crpyto currency balance at current minute
               total_balance,  # your total balance at current minute
               position_current,  # your position for 4 crypto currencies at this minute
               memory  # a class, containing the information you saved so far
               ):
    #The idea of this week's strategy: "Touch and Run strategy"
    #Base on every week maximum up strike return, we set a roof for our return
    #Long sighnal: if the prices reach the roof, then we run.
        position_new = position_current
        #In the first 200 minutes we make sure to invest equal money to the four assets
        #We set 200 because 200 is usually enough to buy until our position value reach our request
        if counter <= 200:
            
            position_new[0] = 22000/data[0,0]
            position_new[1] = 22000/data[1,0]
            position_new[2] = 22000/data[2,0]
            position_new[3] = 22000/data[3,0]
        
        #In the "keep" list, when it reachs the roof, we turn it into "sell" list
        for i in cont:
             if position_new[i]*data[i,0] >= 22080:
                  position_new[i] = 0
                  cont.remove(i)
                  sell.append(i)
        #in the "sell" list, we clear all.
        for i in sell:
            position_new[i] = 0
        
        
        return position_new, memory