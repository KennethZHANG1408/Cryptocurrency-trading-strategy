#import what I need for this strategy
import pandas as pd
import numpy as np
#this is require to load model from working folder
from keras.models import load_model
#set window time for later use
window_len = 20

# load the trained model into this strategy
bch_model = load_model('bch_model.h5')
btc_model = load_model('btc_model.h5')
eth_model = load_model('eth_model.h5')
ltc_model = load_model('ltc_model.h5')
def handle_bar(counter,  # a counter for number of minute bars that have already been tested
               time,  # current time in string format such as "2018-07-30 00:30:00"
               data,  # data for current minute bar (in format 2)
               init_cash,  # your initial cash, a constant
               transaction,  # transaction ratio, a constant
               cash_balance,  # your cash balance at current minute
               crypto_balance,  # your crpyto currency balance at current minute
               total_balance,  # your total balance at current minute
               position_current,  # your position for 4 crypto currencies at this minute
               memory  # a class, containing the information you saved so far
               ):
    

    # The idea of my strategy:
    # Predict future price using deep learning LSTM model 
    #This week I made some small change to my winwo lenth, training activition function and data size.
    #And I tested some threshold for trade value and trade volume
    # Pattern for long signal:
    # When the model predicts there is a relatively large future return

    # Pattern for short signal:
    # When the model predicts there is a negative future return

    # No controlling of the position is conducted yet in this strategy.
    #print(counter)
    i=0
    #print(counter)
    # Get position of last minute
    position_new = position_current
    norm_cols = [coin+metric for coin in ['bt_', 'bc_', 'et_', 'lt_'] for metric in ['close','volume']]
    # Get the head lines for each dataframe
    if (counter == 0):
        #define the headlines of my model data
        memory.data_save = pd.DataFrame(columns = ['bt_close', 'bt_volume', 'bt_close_off_high', 'bt_volatility', 
                                                   'bc_close', 'bc_volume', 'bc_close_off_high', 'bc_volatility',
                                                   'et_close', 'et_volume', 'et_close_off_high', 'et_volatility',
                                                   'lt_close', 'lt_volume', 'lt_close_off_high', 'lt_volatility'])
    #When there is not enough data to calculate, we just store it in memory.data
    if (counter < window_len-1):
        
        memory.data_save.loc[counter] = [data[1,0],data[1,4],2*(data[1,1]-data[1,0])/data[1,3], (data[1,1]-data[1,2])/data[1,3],
                                            data[0,0],data[0,4],2*(data[0,1]-data[0,0])/data[0,3], (data[0,1]-data[0,2])/data[0,3],
                                            data[2,0],data[2,4],2*(data[2,1]-data[2,0])/data[2,3], (data[2,1]-data[2,2])/data[2,3],
                                            data[3,0],data[3,4],2*(data[3,1]-data[3,0])/data[3,3], (data[3,1]-data[3,2])/data[3,3]]
    # When there is enough data to calculate, start to transfer the data into a form that my model needs   
    if (counter >= window_len-1):
        memory.data_save.loc[counter] = [data[1,0],data[1,4],2*(data[1,1]-data[1,0])/data[1,3], (data[1,1]-data[1,2])/data[1,3],
                                            data[0,0],data[0,4],2*(data[0,1]-data[0,0])/data[0,3], (data[0,1]-data[0,2])/data[0,3],
                                            data[2,0],data[2,4],2*(data[2,1]-data[2,0])/data[2,3], (data[2,1]-data[2,2])/data[2,3],
                                            data[3,0],data[3,4],2*(data[3,1]-data[3,0])/data[3,3], (data[3,1]-data[3,2])/data[3,3]]
        
            
        #define and calculate the standard input to be taken into the model
        LSTM_training_inputs = []
        for i in range(len(memory.data_save)-window_len):
            temp_set = memory.data_save[i:(i+window_len)].copy()
            for col in norm_cols:
                temp_set.loc[:, col] = temp_set[col]/temp_set[col].iloc[0] - 1
            LSTM_training_inputs.append(temp_set)
        #in case to special data, e.g. nan and inf.    
        for i in range(0,len(LSTM_training_inputs)):
            LSTM_training_inputs[i] = LSTM_training_inputs[i].replace(np.inf, 0)
    
        for i in LSTM_training_inputs:
            np.nan_to_num(i, copy = False)
        #final step to transfer into the form that my model requires
        LSTM_training_inputs = [np.array(LSTM_training_input) for LSTM_training_input in LSTM_training_inputs]
        LSTM_training_inputs = np.array(LSTM_training_inputs)
        #we don't need to put all data into model, so we just keep the last 10
        if (counter > window_len):
            memory.data_save=memory.data_save[-window_len:]
            bt_pre = btc_model.predict(LSTM_training_inputs)
            #print(bt_pre[-1])
            #Here we input the data into model, and see what the model predicts
            #If the model is outputing sell signal, we sell. Vise versa.
            if bt_pre[-1] > 0.005:
                position_new[1] += 0.01
            if bt_pre[-1] < -0.002:
                position_new[1] = 0
            bc_pre = bch_model.predict(LSTM_training_inputs)
            #print(bc_pre[-1])
            if bc_pre[-1] > 0.005:
                position_new[0] += 0.1
            if bc_pre[-1] <-0.002:
                position_new[0] = 0
                        
            et_pre = eth_model.predict(LSTM_training_inputs)
            #print(et_pre[-1])
            if et_pre[-1] > 0.005:
                position_new[2] += 0.1
            if et_pre[-1] < -0.002:
                position_new[2] = 0
            lt_pre = ltc_model.predict(LSTM_training_inputs)
            #print(lt_pre[-1])
            if lt_pre[-1] > 0.005:
                position_new[3] += 0.1
            if lt_pre[-1] < -0.002:
                position_new[3] = 0
    
            
    # End of strategy
    return position_new, memory