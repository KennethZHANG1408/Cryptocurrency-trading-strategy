import pandas as pd
import numpy as np
from statsmodels.tsa.stattools import adfuller
bc_info = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\data\\BCH-USD_T(2).csv")
bt_info = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\data\\BTC-USD_T(2).csv")
et_info = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\data\\ETH-USD_T(2).csv")
lt_info = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\data\\LTC-USD_T(2).csv")

bt_info = bt_info.rename(columns={'high':'bt_high', 'low':'bt_low', 'open':'bt_open', 'close': 'bt_close', 'volume':'bt_volume'})
bc_info = bc_info.rename(columns={'high':'bc_high', 'low':'bc_low', 'open':'bc_open', 'close': 'bc_close', 'volume':'bc_volume'})
et_info = et_info.rename(columns={'high':'et_high', 'low':'et_low', 'open':'et_open', 'close': 'et_close', 'volume':'et_volume'})
lt_info = lt_info.rename(columns={'high':'lt_high', 'low':'lt_low', 'open':'lt_open', 'close': 'lt_close', 'volume':'lt_volume'})

# put the data of four coins into one variable
market_info = pd.merge(bt_info,bc_info, on=['time'])
market_info = pd.merge(market_info,et_info, on=['time'])
market_info = pd.merge(market_info,lt_info, on=['time'])
market_info = market_info[market_info['time']>='2018-10-13 06:00:00']
market_info = market_info[market_info['time']<='2018-10-14 05:59:59']
bt_close=list(market_info['bt_close'])
bc_close=list(market_info['bc_close'])
lt_close=list(market_info['lt_close'])
et_close=list(market_info['et_close'])
close = pd.DataFrame(bt_close)
close.to_csv("bt_close price.csv")
close = pd.DataFrame(bc_close)
close.to_csv("bc_close price.csv")
close = pd.DataFrame(lt_close)
close.to_csv("lt_close price.csv")
close = pd.DataFrame(et_close)
close.to_csv("et_close price.csv")

bt_lt = np.array(bt_close)-np.array(lt_close)
bc_et = np.array(bc_close)-np.array(et_close)
bt_et = np.array(bt_close)-np.array(et_close)
et_lt = np.array(et_close)-np.array(lt_close)

btlt_adftest = adfuller(bt_lt)
bcet_adftest = adfuller(bc_et)
btet_adftest = adfuller(bt_et)
etlt_adftest = adfuller(et_lt)
coef=np.corrcoef([bt_close,bc_close,lt_close,et_close])

bt_ltstd = np.std(bt_lt)
bt_ltmean = np.mean(bt_lt)
bc_etstd = np.std(bc_et)
bc_etmean = np.mean(bc_et)
bt_etstd = np.std(bt_et)
bt_etmean = np.mean(bt_et)
et_ltstd = np.std(et_lt)
et_ltmean = np.mean(et_lt)

