# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 19:58:59 2018

@author: asus
"""
#This week we try a easy statistics arbitrge strategy
#We see that some of the correlationships are high, so we try to use the price difference of two relevant assets
#The differenct of these two assets should be normal distribution
#If the difference is higher than some range, we think the range will be smaller, we short the higher one and long the lower one
#Vise versa
import pandas as pd
import numpy as np

#read the data in the folder for comparation
bt_close = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\MAFS\\python\\Last Samurai\\bt_close price.csv")
bt_close = list(bt_close['0'])
bc_close = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\MAFS\\python\\Last Samurai\\bc_close price.csv")
bc_close = list(bc_close['0'])
et_close = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\MAFS\\python\\Last Samurai\\et_close price.csv")
et_close = list(et_close['0'])
lt_close = pd.read_csv("E:\\Desktop\\2018_2019Fall\\MAFS5140\\MAFS\\python\\Last Samurai\\lt_close price.csv")
lt_close = list(lt_close['0'])


bt_lt = np.array(bt_close)-np.array(lt_close)
bc_et = np.array(bc_close)-np.array(et_close)
bt_et = np.array(bt_close)-np.array(et_close)
et_lt = np.array(et_close)-np.array(lt_close)

#get the sample mean and sample std
bc_etmean = np.mean(bc_et)
bc_etstd = np.std(bc_et)
bt_etmean = np.mean(bt_et)
bt_etstd = np.std(bt_et)
bt_ltmean = np.mean(bt_lt)
bt_ltstd = np.std(bt_lt)
et_ltmean = np.mean(et_lt)
et_ltstd = np.std(et_lt)
#import what I need for this strategy
def handle_bar(counter,  # a counter for number of minute bars that have already been tested
               time,  # current time in string format such as "2018-07-30 00:30:00"
               data,  # data for current minute bar (in format 2)
               init_cash,  # your initial cash, a constant
               transaction,  # transaction ratio, a constant
               cash_balance,  # your cash balance at current minute
               crypto_balance,  # your crpyto currency balance at current minute
               total_balance,  # your total balance at current minute
               position_current,  # your position for 4 crypto currencies at this minute
               memory  # a class, containing the information you saved so far
               ):
     position_new = position_current
     global bc_etmean
     global bc_etstd
     global bt_etmean
     global bt_etstd
     global bt_ltmean 
     global bt_ltstd
     global et_ltmean
     global et_ltstd
     global bt_close
     global et_close
     global lt_close
     global bc_close
     bc = data[0,0]
     
     #print(bt)
     bt = data[1,0]
     #print(bc)
     et = data[2,0]
     #print(et)
     lt = data[3,0]
     #print(lt)
     
     if bc-et < bc_etmean - 1*bc_etstd:
         position_new[0] += 0.01
         position_new[2] = 0
     if bc-et > bc_etmean + 1*bc_etstd:
         position_new[0] = 0
         position_new[2] += 0.1
    
     if bt-et < bt_etmean - 1*bt_etstd:
         position_new[1] += 0.001
         position_new[2] = 0
     if bt-et > bt_etmean + 1*bt_etstd:
         position_new[1] = 0
         position_new[2] += 0.01
     
     if bt-lt < bt_ltmean - 1*bt_ltstd:
         position_new[1] += 0.001
         position_new[3] = 0
     if bt-lt > bt_ltmean + 1*bt_ltstd:
         position_new[1] = 0
         position_new[3] += 0.05
   
     if et-lt < et_ltmean - 1*et_ltstd:
         position_new[2] += 0.03
         position_new[3] = 0 
     if et-lt > et_ltmean + 1*et_ltstd:
         position_new[2] = 0
         position_new[3] += 0.05
    
     #update the data list 
     bt_close.append(bt)
     bc_close.append(bc)
     et_close.append(et)
     lt_close.append(lt)
     bt_close = bt_close[1:]
     bc_close = bc_close[1:]
     et_close = et_close[1:]
     lt_close = lt_close[1:]
     # End of strategy
     return position_new, memory
